module.exports = {
  mongoURI: "mongodb://localhost/mydb",
  secretOrKey: "secret"
};

{
  /*  
    mongoURI: "mongodb://localhost/earthmovingmsp"
  */
}
