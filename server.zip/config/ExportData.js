module.exports = {
  WomenSportShoes: "women sport shoes",
  MenSportShoes: "men sport shoes",
  WomenSlippers: "women slippers",
  MenSlippers: "men slippers"
};
