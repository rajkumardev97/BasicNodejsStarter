module.exports = {
  superadminrodleid: "atozadmin@30876DC5-7DF0-4103-A475-998C11E0A7E6"
};
